package com.verint.estore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.verint.estore.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
	Item findByItemId(String itemId);
}
