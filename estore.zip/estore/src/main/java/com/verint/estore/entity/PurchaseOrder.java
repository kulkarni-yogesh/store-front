package com.verint.estore.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Pattern;

@Entity
public class PurchaseOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String orderId;

	@ManyToOne
	private Item item;

	@Pattern(regexp = "\\b[A-Za-z\\s]+\\b", message = "Full Name should only contain letters A-Z, a-z, and spaces")
	private String fullName;

	private String address;

	@Pattern(regexp = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b", message = "Invalid email address")
	private String email;

	@Pattern(regexp = "\\d{3}-\\d{3}-\\d{4}", message = "Phone Number should be in the format xxx-xxx-xxxx")
	private String phoneNumber;

	@Pattern(regexp = "\\d{19}", message = "Credit Card should be 19 digits long and contain only digits")
	private String creditCardNumber;

	// Constructors, getters, and setters

	public PurchaseOrder() {
	}

	public PurchaseOrder(String orderId, Item item, String fullName, String address, String email, String phoneNumber,
			String creditCardNumber) {
		this.orderId = orderId;
		this.item = item;
		this.fullName = fullName;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.creditCardNumber = creditCardNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}
