package com.verint.estore.entity;

import javax.validation.constraints.*;

public class OrderRequest {
	@NotEmpty(message = "ItemId is required")
	private String itemId;

	@Pattern(regexp = "\\b[A-Za-z\\s]+\\b", message = "Full Name should only contain letters A-Z, a-z, and spaces")
	private String fullName;

	@NotEmpty(message = "Address is required")
	private String address;

	@Pattern(regexp = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b", message = "Invalid email address")
	private String email;

	@Pattern(regexp = "\\d{3}-\\d{3}-\\d{4}", message = "Phone Number should be in the format xxx-xxx-xxxx")
	private String phoneNumber;

	@Pattern(regexp = "\\d{19}", message = "Credit Card should be 19 digits long and contain only digits")
	private String creditCardNumber;

	// Constructors, getters, and setters

	public OrderRequest() {
	}

	public OrderRequest(String itemId, String fullName, String address, String email, String phoneNumber,
			String creditCardNumber) {
		this.itemId = itemId;
		this.fullName = fullName;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.creditCardNumber = creditCardNumber;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}
