package com.verint.estore.config;

import org.springframework.context.annotation.Configuration;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

@Configuration
public class SwaggerConfig {

	@Value("${springdoc.api-docs.path}")
	private String apiDocsPath;

	@Bean
	public GroupedOpenApi api() {
		return GroupedOpenApi.builder().group("API").pathsToMatch("/api/**").build();
	}
}
