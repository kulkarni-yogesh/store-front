package com.verint.estore.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.verint.estore.entity.Item;
import com.verint.estore.entity.OrderRequest;
import com.verint.estore.entity.PurchaseOrder;
import com.verint.estore.repository.ItemRepository;
import com.verint.estore.repository.OrderRepository;

@RestController
@Validated
@RequestMapping("/api")
public class StoreController {
	private static final int PAGE_SIZE = 10;

	private final ItemRepository itemRepository;
	private final OrderRepository orderRepository;

	@Autowired
	public StoreController(ItemRepository itemRepository, OrderRepository orderRepository) {
		this.itemRepository = itemRepository;
		this.orderRepository = orderRepository;
		initializeDummyData();
	}

	@GetMapping("/items")
	public ResponseEntity<List<Item>> getItems(@RequestParam(defaultValue = "0") @Min(0) int page) {
		PageRequest pageRequest = PageRequest.of(page, PAGE_SIZE);
		Page<Item> itemPage = itemRepository.findAll(pageRequest);

		if (itemPage.isEmpty()) {
			return ResponseEntity.noContent().build();
		}

		return ResponseEntity.ok(itemPage.getContent());
	}

	@PostMapping("/checkout")
	public ResponseEntity<String> checkout(@RequestBody @Valid OrderRequest orderRequest) {
		Item item = itemRepository.findByItemId(orderRequest.getItemId());
		if (item == null) {
			return ResponseEntity.badRequest().body("Invalid ItemId");
		}

		PurchaseOrder order = new PurchaseOrder();
		order.setOrderId(generateOrderId());
		order.setItem(item);
		order.setFullName(orderRequest.getFullName());
		order.setAddress(orderRequest.getAddress());
		order.setEmail(orderRequest.getEmail());
		order.setPhoneNumber(orderRequest.getPhoneNumber());
		order.setCreditCardNumber(orderRequest.getCreditCardNumber());

		orderRepository.save(order);

		return ResponseEntity.status(HttpStatus.CREATED).body(order.getOrderId());
	}

	@GetMapping("/order/{orderId}")
	public ResponseEntity<PurchaseOrder> getOrder(@PathVariable String orderId) {
		PurchaseOrder order = orderRepository.findByOrderId(orderId).orElse(null);

		if (order == null) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(order);
	}

	private String generateOrderId() {

		return UUID.randomUUID().toString();

	}

	// Inserting some dummy item data

	private void initializeDummyData() {
		Item item1 = new Item("ITEM-123", "Sample Item 1", "This is a sample item", new BigDecimal("10.0"), 1);
		Item item2 = new Item("ITEM-456", "Sample Item 2", "This is another sample item", new BigDecimal("20.0"), 1);

		itemRepository.save(item1);
		itemRepository.save(item2);

		PurchaseOrder order1 = new PurchaseOrder("ORDER-123", item1, "John Doe", "123 Main St", "johndoe@example.com",
				"123-456-7890", "1234567890123456789");
		PurchaseOrder order2 = new PurchaseOrder("ORDER-456", item2, "Jane Smith", "456 Elm St",
				"janesmith@example.com", "987-654-3210", "9876543210987654321");

		orderRepository.save(order1);
		orderRepository.save(order2);
	}

}
